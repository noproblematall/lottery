<?php $__env->startSection('css'); ?>
    <style>
        div.sales {
            margin: 50px auto;
            color:white;
        }
        div.sales table{
            color:white;
        }
        div.sales table td{
            width: 50%;
        }
        div.sales table tr:hover{
            color:wheat;
        }
        span.date {
            color: white;
            margin-right:10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<span class="date"><?php echo e($date); ?></span>
<a href="<?php echo e(route('home')); ?>" class="btn btn-primary">Back</a>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="sales">
                <h3 class="text-center">Sales Summary</h3>
                <table class="table table-striped table-hover table-bordered">
                    <tbody>
                        <tr>
                            <td>Current Balance</td>
                            <td><?php echo e($current_balance); ?></td>
                        </tr>
                        <tr>
                            <td>Pending Tickets Total Amount</td>
                            <td><?php echo e($sum_of_amount); ?></td>
                        </tr>
                        <tr>
                            <td>Betting Pool</td>
                            <td><?php echo e($name); ?></td>
                        </tr>
                        <tr>
                            <td>Sales</td>
                            <td><?php echo e($today_balance); ?></td>
                        </tr>
                        <tr>
                            <td>Pending</td>
                            <td><?php echo e($pending_tickets_number); ?></td>
                        </tr>
                        <tr>
                            <td>Losers</td>
                            <td><?php echo e($loser_tickets_number); ?></td>
                        </tr>
                        <tr>
                            <td>Winners</td>
                            <td><?php echo e($win_tickets_number); ?></td>
                        </tr>
                        <tr>
                            <td>Prizes</td>
                            <td><?php echo e($prizes); ?></td>
                        </tr>
                        <tr>
                            <td>Net</td>
                            <td><?php echo e($today_balance); ?></td>
                        </tr>
                        <tr>
                            <td>Final</td>
                            <td><?php echo e($today_balance); ?></td>
                        </tr>
                        <tr>
                            <td>Balance</td>
                            <td><?php echo e($balance); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\lottery\resources\views/summary.blade.php ENDPATH**/ ?>