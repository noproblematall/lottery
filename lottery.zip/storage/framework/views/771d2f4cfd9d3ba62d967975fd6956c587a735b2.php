<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/user.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
    <style>
        
    </style>
</head>
<body>
    <div id="app">
            <?php echo $__env->yieldContent('content'); ?>
    </div>

    
    <!-- Scripts -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/poper.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" ></script>
    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>" ></script>
    
    <?php echo $__env->yieldContent('modal'); ?>
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/layouts/app.blade.php ENDPATH**/ ?>