<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="wrap-print">
    <style>
        .print-container {
            background: white;
            padding:40px;
        }
        .logo-text{
            margin:50px auto;
        }
        p {
            margin-bottom: 5px;
        }
        table thead tr th, table tbody tr td{
            padding-left: 10px;
            padding-right: 10px;
        }
        table tbody{
            text-align: left;
        }
        .general-info p{
            font-style: italic;
        }
    </style>
    <div class="container print-container" id="ticket_result">
        <div class="row">
            <div class="col-md-12">
                <div class="logo-text text-center">
                    <h1 style="font-weight: bold;">Kaizer & Assoc</h1>
                    <h1>**&nbsp;&nbsp; ORIGINAL &nbsp;&nbsp;**</h1>
                    <p>06/14/2019 01 : 24 PM</p>
                </div>
            </div>
            <div class="col-md-12">
                <div class="ticket-info" style="margin-left:300px;margin-bottom:40px;">
                    <p>Ticket: <span>001 - 280 - 014030856</span></p>
                    <p>Fecha: <span>06/14/2019 01 : 24 PM</span></p>
                    <p>2BCC2C307D316B5D3D71032B957E7E93</p>
                    <h3>573843071605</h3>
                </div>
            </div>
            <div class="col-md-12">
                <div class="ticket-detail text-center">
                    <p style="font-weight:bolder">------------------------------------------------</p>
                    <p>FLORIDA AM : 1.00</p>
                    <p style="font-weight:bolder">------------------------------------------------</p>
                    <table style="margin:0 auto;">
                        <thead>
                            <tr>
                                <th>JUGADA</th>
                                <th>MONTO</th>
                                <th>JUGADA</th>
                                <th>MONTO</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>12</td>
                                <td>1</td>
                                <td>22</td>
                                <td>10</td>
                            </tr>
                        </tbody>
                        
                    </table>
                    <h2>-- TOTAL : 1.00 --</h2>
                </div>
            </div>
            <div class="col-md-12">
                <div class="general-info text-center">
                    <p>1st:$65(00-99):$60 2nd:$15</p>
                    <p>3rd:$10 First Only and Pick2:$80</p>
                    <p>Pale:$1,000 SuperPale:$2,000</p>
                    <p>Cash3:$700(000-999:$500)</p>
                    <p>Play4:$4,000 Pick5:$40,000</p>
                    <p>Kole3:$10,000</p>
                    <p>NO TICKET NO MONEY . WE DON'T P A Y</p>
                    <p>DOUBLE P ALE.</p>
                </div>
            </div>
            
        </div>
        
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('js/print.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('#winning_number').click(function(){
                $("#win_modal").modal();
            })

            $('#print_win').click(function(){
                printJS({
                    printable: 'print_result',
                    type: 'html',
                    targetStyles: ['*'],
                    documentTitle:'Winning Numbers'
                })
            })
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\lottery\resources\views/print.blade.php ENDPATH**/ ?>