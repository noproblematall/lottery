<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"/>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'CMS')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>    

    <!-- Styles -->
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <style>
        .bg-plum-plate {
            background-color:#05052a !important;
        }
        .modal-content {
            background-color:#05052a;
            box-shadow: 0 0 15px 3px;
            border-radius: 1.3rem;
        }
    </style>
</head>

<body>
<div class="app-container app-theme-white body-tabs-shadow">
        <div class="app-container">
            <div class="h-100 bg-plum-plate bg-animation">
                <div class="mx-auto mt-5 text-center">
                    <img src="<?php echo e(asset('images/logo.png')); ?>" alt="" srcset="" width="250" height="144">
                </div>
                <div class="d-flex justify-content-center align-items-center">
                    
                    <div class="mx-auto app-login-box col-md-8">
                        
                        <div class="modal-dialog w-100 mx-auto">
                            <div class="modal-content">
                                <div class="modal-body">
                                    <div class="h5 modal-title text-center">
                                        <h4 class="mt-2">
                                            <span>Please sign in to your account below.</span>
                                        </h4>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('login')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-row">
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <input name="name" id="exampleEmail" placeholder="Name here..." value="<?php echo e(old('name')); ?>" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" autofocus>
                                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="position-relative form-group">
                                                    <input name="password" id="examplePassword" placeholder="Password here..." type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            
                                            <?php if(session('block')): ?>
                                                <span class="invalid-feedback" role="alert" style="display:block;font-size:100%;">
                                                    <strong><?php echo e(session('block')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="divider"></div>
                                        <div class="text-center">
                                            <button type="submit"  class="btn btn-primary btn-lg"><?php echo e(__('Login')); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="text-center text-white opacity-8 mt-3">&copy; 2019 kaizerassoc.com</div>
                    </div>
                </div>
            </div>
        </div>
</div>
</html>
<?php /**PATH C:\wamp64\www\lottery\resources\views/auth/login.blade.php ENDPATH**/ ?>