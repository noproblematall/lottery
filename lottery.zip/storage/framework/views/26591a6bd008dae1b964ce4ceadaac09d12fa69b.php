<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"/>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'CMS')); ?></title>

    <!-- Scripts -->
    
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">

    <!-- jQuery library -->
    <script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>

    <!-- Popper JS -->
    

    <!-- Latest compiled JavaScript -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('js/sweetalert.min.js')); ?>" defer></script>
    
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    

    <script type="text/javascript" language="javascript" src="<?php echo e(asset('DataTables/js/jquery.dataTables.min.js')); ?>" defer></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('DataTables/js/dataTables.bootstrap4.min.js')); ?>" defer></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('DataTables/js/dataTables.buttons.min.js')); ?>" defer></script>
    <script type="text/javascript" language="javascript" src="<?php echo e(asset('DataTables/js/buttons.bootstrap4.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div class="app-container app-theme-white body-tabs-shadow fixed-header fixed-sidebar">
        <div class="app-header header-shadow bg-dark header-text-light">
            <div class="app-header__logo">
                <div class="logo-src"></div>
                <div class="header__pane ml-auto">
                    <div>
                        <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div>
            <div class="app-header__mobile-menu">
                <div>
                    <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                        <span class="hamburger-box">
                            <span class="hamburger-inner"></span>
                        </span>
                    </button>
                </div>
            </div>
            <div class="app-header__menu">
                <span>
                    <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                        <span class="btn-icon-wrapper">
                            <i class="fa fa-ellipsis-v fa-w-6"></i>
                        </span>
                    </button>
                </span>
            </div>    
            <div class="app-header__content">                
                <div class="app-header-right">
                    <div class="header-btn-lg pr-0">
                        <div class="widget-content p-0">
                            <div class="widget-content-wrapper">
                                <div class="widget-content-left">
                                    <div class="btn-group">
                                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
                                            <img width="42" class="rounded-circle" src="<?php echo e(asset(Auth::user()->photo)); ?>" alt="Avatar">
                                            <i class="fa fa-angle-down ml-2 opacity-8"></i>
                                        </a>
                                        <div tabindex="-1" role="menu" aria-hidden="true" class="rm-pointers dropdown-menu-lg dropdown-menu dropdown-menu-right">
                                            <div class="dropdown-menu-header">
                                                <div class="dropdown-menu-header-inner bg-info">
                                                    <div class="menu-header-image opacity-2" style="background-image: url('<?php echo e(asset('images/dropdown-header/city1.jpg')); ?>');"></div>
                                                    <div class="menu-header-content text-left">
                                                        <div class="widget-content p-0">
                                                            <div class="widget-content-wrapper">
                                                                <div class="widget-content-left mr-3">
                                                                    <img width="42" class="rounded-circle"
                                                                         src="<?php echo e(asset(Auth::user()->photo)); ?>" alt="Avatar">
                                                                </div>
                                                                <div class="widget-content-left">
                                                                    <div class="widget-heading"><?php echo e(Auth::user()->username); ?></div>
                                                                    <div class="widget-subheading opacity-8">Welcome to CMS</div>
                                                                </div>
                                                                <div class="widget-content-right mr-2">
                                                                    <a class="btn-pill btn-shadow btn-shine btn btn-focus" href="<?php echo e(route('logout')); ?>"onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                                                                        <?php echo e(__('Logout')); ?>

                                                                    </a>
                                                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                                                        <?php echo csrf_field(); ?>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="text-center">
                                                <h5>Welcome to CMS</h5>
                                            </div>
                                            <ul class="nav flex-column">
                                                <li class="nav-item-divider mb-0 nav-item"></li>
                                                <div class="mt-2 text-center">
                                                    <a class="btn-pill btn-shadow btn-shine btn btn-focus" href="<?php echo e(route('setting')); ?>">
                                                        <?php echo e(__('User Setting')); ?>

                                                    </a>
                                                </div>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="widget-content-left  ml-3 header-user-info">
                                    <div class="widget-heading">
                                        <?php echo e(Auth::user()->username); ?>

                                    </div>
                                    <div class="widget-subheading">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="app-main">
            <div class="app-sidebar sidebar-shadow bg-dark sidebar-text-light">
                <div class="app-header__logo">
                    <div class="logo-src"></div>
                    <div class="header__pane ml-auto">
                        <div>
                            <button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
                                <span class="hamburger-box">
                                    <span class="hamburger-inner"></span>
                                </span>
                            </button>
                        </div>
                    </div>
                </div>
                <div class="app-header__mobile-menu">
                    <div>
                        <button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
                <div class="app-header__menu">
                    <span>
                        <button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
                            <span class="btn-icon-wrapper">
                                <i class="fa fa-ellipsis-v fa-w-6"></i>
                            </span>
                        </button>
                    </span>
                </div>    
                <div class="scrollbar-sidebar">
                    <div class="app-sidebar__inner">
                        <ul class="vertical-nav-menu">
                            <br />
                            <li>
                                <a href="<?php echo e(route('admin.index')); ?>">
                                    <i class="metismenu-icon pe-7s-home"></i>
                                    HOME
                                </a>                                    
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.user')); ?>">
                                    <i class="metismenu-icon pe-7s-users"></i>
                                    USER MANAGEMENT
                                </a>                                    
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.win_number')); ?>">
                                    <i class="metismenu-icon pe-7s-medal"></i>
                                    WINNING NUMBERS
                                </a>                                    
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.avail_amount')); ?>">
                                    <i class="metismenu-icon pe-7s-diamond"></i>
                                    AVAILABLE AMOUNTS
                                </a>                                    
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </div>
            <div class="app-main__outer">
                <div class="app-main__inner">
                    <div class="app-page-title">
                        <div class="page-title-wrapper">
                            <?php echo $__env->yieldContent('subtitle'); ?>
                        </div>
                    </div>
                    <div class="tab-content">
                        <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
                            
                                <?php echo $__env->yieldContent('content'); ?>
                            
                        </div>
                    </div>
                </div>                    
            </div>
        </div>
    </div>    
    
    <?php echo $__env->yieldContent('modal'); ?>
    <?php echo $__env->yieldContent('script'); ?>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\lottery\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>