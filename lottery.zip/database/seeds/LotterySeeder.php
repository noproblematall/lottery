<?php

use Illuminate\Database\Seeder;
use App\Models\Lottery;
class LotterySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Lottery::create(['name' => 'New York AM','abbrev' => 'NY AM']);
        Lottery::create(['name' => 'Florida AM','abbrev' => 'FL AM']);
        Lottery::create(['name' => 'New Jersey AM','abbrev' => 'NJ AM']);
        Lottery::create(['name' => 'Georgia AM','abbrev' => 'GA AM']);
        Lottery::create(['name' => 'FL Pick2 AM','abbrev' => 'P2AM']);
        Lottery::create(['name' => 'New York PM','abbrev' => 'NY PM']);
        Lottery::create(['name' => 'New Jersey PM','abbrev' => 'NJ PM']);
        Lottery::create(['name' => 'Florida PM','abbrev' => 'FL PM']);
        Lottery::create(['name' => 'Georgia Evening PM','abbrev' => 'GA PM']);
        Lottery::create(['name' => 'FL Pick2 PM','abbrev' => 'P2PM']);

    }
}
